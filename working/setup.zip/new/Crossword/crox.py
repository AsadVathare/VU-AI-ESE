from typing import List
def check_right(i, j, grid) -> tuple[int, int, int]:
    counter = 0
    while (counter + j) < len(grid[i]):
        if grid[i][j + counter] == ' ':
            counter += 1
        else:
            break
    if counter < 2:
        return None
    else: 
        return (i, j, counter)
 
def check_down(i, j, grid) -> tuple[int, int, int]:
    counter = 0
    while (counter + i) < len(grid):
        if grid[i + counter][j] == ' ':
            counter += 1
        else:
            break
    if counter < 2:
        return None
    else:
        return (i, j, counter)
 
def get_across_slots(grid: list[str]):
    accross_slots = []
    i = 0
    while i < len(grid):
        j = 0
        while j < len(grid[i]):
            if grid[i][j] == ' ':
                if slot := check_right(i, j, grid):
                    accross_slots.append(slot)
                    j += slot[2]
            j += 1
        i += 1
    return accross_slots
def get_down_slots(grid: list[str]):
    down_slots = []
    for j in range(len(grid[0])):
        i = 0
        while i < len(grid):
            if grid[i][j] == ' ':
                if slot := check_down(i, j, grid):
                    down_slots.append(slot)
                    i += slot[2]
            i += 1
    return down_slots


def start(across_words: List[str], down_words: List[str], grid: List[str]) -> List[str]:
    across_slots = get_across_slots(grid)
    down_slots = get_down_slots(grid)

    # We need a mutable grid, so we use list[list[str]]
    mut_grid = []
    for i in range(len(grid)):
        arr = []
        for j in range(len(grid[i])):
            arr.append([grid[i][j]])
        mut_grid.append(arr)

    # Start filling the across words
    for word in across_words:
        for slot in across_slots:
            if len(word) == slot[2]:
                x, y, _ = slot
                for counter, letter in enumerate(word):
                    mut_grid[x][y + counter] = [letter]
                across_slots.remove(slot)
                break

    # Start filling the down words
    for word in down_words:
        for slot in down_slots:
            if len(word) == slot[2]:
                x, y, _ = slot
                for counter, letter in enumerate(word):
                    mut_grid[x + counter][y] = [letter]
                down_slots.remove(slot)
                break

    # Convert list[list[str]] to list[str]
    grid = []
    for i in range(len(mut_grid)):
        string = ""
        for j in range(len(mut_grid[i])):
            for k in range(len(mut_grid[i][j])):
                string += mut_grid[i][j][k][0]
        grid.append(string)

    return grid


def display_grid(grid: list[str]) -> None:
    for row in grid:
        for col in row:
            print(f"{col:>2}", end='')
        print()
def main():
    ACROSS = ['ACROSS', 'NIL']
    DOWN = ['SCAN', 'DOWN','BOSS']
    grid = [
   "###### #",
   "###### #",
   "## # # #",
   "#      #",
   "## # ###",
   "## #   #",
   "########"
    ]
    print(" The Initial Crossword is ".center(40, '='))
    display_grid(grid)
    print("The Across Words Are : ", ', '.join(ACROSS))
    print("The Down Words Are : ", ', '.join(DOWN))
    result = start(ACROSS, DOWN, grid)
    print('\n\n')
    print(" The Final Crossword is ".center(40, '='))
    display_grid(result)
main()